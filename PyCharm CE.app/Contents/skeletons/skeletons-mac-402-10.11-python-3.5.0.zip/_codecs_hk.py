# encoding: utf-8
# module _codecs_hk
# from (pre-generated)
# by generator 1.146
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__map_big5hkscs = None # (!) real value is ''

__map_big5hkscs_bmp = None # (!) real value is ''

__map_big5hkscs_nonbmp = None # (!) real value is ''

__spec__ = None # (!) real value is ''

