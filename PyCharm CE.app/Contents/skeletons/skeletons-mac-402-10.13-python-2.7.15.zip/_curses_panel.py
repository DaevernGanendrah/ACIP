# encoding: utf-8
# module _curses_panel
# from (pre-generated)
# by generator 1.146
# no doc
# no imports

# Variables with simple values

version = '2.1'

__version__ = '2.1'

# functions

def bottom_panel(*args, **kwargs): # real signature unknown
    pass

def new_panel(*args, **kwargs): # real signature unknown
    pass

def top_panel(*args, **kwargs): # real signature unknown
    pass

def update_panels(*args, **kwargs): # real signature unknown
    pass

# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



