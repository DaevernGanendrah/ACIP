# encoding: utf-8
# module _codecs_kr
# from (pre-generated)
# by generator 1.146
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes
# variables with complex values

__map_cp949 = None # (!) real value is ''

__map_cp949ext = None # (!) real value is ''

__map_ksx1001 = None # (!) real value is ''

