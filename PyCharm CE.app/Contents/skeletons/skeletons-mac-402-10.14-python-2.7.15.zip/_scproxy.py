# encoding: utf-8
# module _scproxy
# from (pre-generated)
# by generator 1.146
# no doc
# no imports

# functions

def _get_proxies(*args, **kwargs): # real signature unknown
    pass

def _get_proxy_settings(*args, **kwargs): # real signature unknown
    pass

# no classes
