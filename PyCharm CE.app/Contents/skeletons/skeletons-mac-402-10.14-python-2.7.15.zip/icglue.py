# encoding: utf-8
# module icglue
# from (pre-generated)
# by generator 1.146
""" Implements low-level Internet Config interface """

# imports
from MacOS import error


# functions

def ICStart(*args, **kwargs): # real signature unknown
    """ (OSType)->ic_instance; Create an Internet Config instance """
    pass

# no classes
