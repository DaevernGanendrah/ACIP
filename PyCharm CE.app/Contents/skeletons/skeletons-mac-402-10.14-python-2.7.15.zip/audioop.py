# encoding: utf-8
# module audioop
# from (pre-generated)
# by generator 1.146
# no doc
# no imports

# functions

def add(*args, **kwargs): # real signature unknown
    pass

def adpcm2lin(*args, **kwargs): # real signature unknown
    pass

def alaw2lin(*args, **kwargs): # real signature unknown
    pass

def avg(*args, **kwargs): # real signature unknown
    pass

def avgpp(*args, **kwargs): # real signature unknown
    pass

def bias(*args, **kwargs): # real signature unknown
    pass

def cross(*args, **kwargs): # real signature unknown
    pass

def findfactor(*args, **kwargs): # real signature unknown
    pass

def findfit(*args, **kwargs): # real signature unknown
    pass

def findmax(*args, **kwargs): # real signature unknown
    pass

def getsample(*args, **kwargs): # real signature unknown
    pass

def lin2adpcm(*args, **kwargs): # real signature unknown
    pass

def lin2alaw(*args, **kwargs): # real signature unknown
    pass

def lin2lin(*args, **kwargs): # real signature unknown
    pass

def lin2ulaw(*args, **kwargs): # real signature unknown
    pass

def max(*args, **kwargs): # real signature unknown
    pass

def maxpp(*args, **kwargs): # real signature unknown
    pass

def minmax(*args, **kwargs): # real signature unknown
    pass

def mul(*args, **kwargs): # real signature unknown
    pass

def ratecv(*args, **kwargs): # real signature unknown
    pass

def reverse(*args, **kwargs): # real signature unknown
    pass

def rms(*args, **kwargs): # real signature unknown
    pass

def tomono(*args, **kwargs): # real signature unknown
    pass

def tostereo(*args, **kwargs): # real signature unknown
    pass

def ulaw2lin(*args, **kwargs): # real signature unknown
    pass

# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



