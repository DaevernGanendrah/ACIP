# encoding: utf-8
# module _codecs_tw
# from (pre-generated)
# by generator 1.146
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__map_big5 = None # (!) real value is ''

__map_cp950ext = None # (!) real value is ''

__spec__ = None # (!) real value is ''

