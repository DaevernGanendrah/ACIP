# encoding: utf-8
# module gestalt
# from (pre-generated)
# by generator 1.146
# no doc
# no imports

# functions

def gestalt(*args, **kwargs): # real signature unknown
    pass

# no classes
