# encoding: utf-8
# module _ctypes_test
# from (pre-generated)
# by generator 1.146
# no doc
# no imports

# functions

def func(*args, **kwargs): # real signature unknown
    pass

def func_si(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

